


   Installation
   ------------

   a) Open on your ServoCommander-CD the directory "ENGLISH"
   b) Start the program "setup.exe"
   c) Please read our Software licence agreements.
   d) Follow the installation instructions of the installation program.
   e) ServoCommander is installed now. 
