


   Installation
   ------------

   a) Open on your SE-Commander-CD the directory "ENGLISH"
   b) Start the program "setup.exe"
   c) Please read our Software licence agreements.
   d) Follow the installation instructions of the installation program.
   e) SE-Commander is installed now. 
