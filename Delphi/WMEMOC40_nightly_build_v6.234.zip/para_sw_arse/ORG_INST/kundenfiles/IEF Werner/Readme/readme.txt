


   Installation
   ------------

   a) Open on your S2 Commander-CD the directory "ENGLISH"
   b) Start the program "setup.exe"
   c) Please read our software licence agreements.
   d) Follow the installation instructions of the installation program.
   e) S2 Commander is installed now.
