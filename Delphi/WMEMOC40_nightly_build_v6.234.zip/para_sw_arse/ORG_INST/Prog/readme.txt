
     DevCont - Developer's Connector
 Copyright (c)2001,2002 by Stefan Partusch
-------------------------------------------


=== Contents

    1. Introduction
    2. The interface
    3. The settings
    4. The different modes

===========================================




 1. Introduction
-----------------
 DevCont is a program with very many possibilities. It is capable of both
 TCP/IP and UDP/IP. Furthermore it has three different modes to send and receive data,
 which are described more exactly in section 4.
 Due to this versatility DevCont addresses itself to advanced users or developers.
 DevCont has two main fields of application:
 1. DevCont is to enable developers to test the behavior of their server applications
    in a very simple way, without the necessity to specially write a client for this task.
 2. It is also to give to developers the possibility of simply testing protocols BEFORE they
    develop applications for it. Nothing is so annoying, as if one wrote several-day-long at
    an application to only state that it does not work properly, because one misunterstood a RFC.
 In addition, "normal" users can use DevCont, in order to improve their knowledge of
 protocols used in the internet or simply to play around.


 2. The interface
--------------------
 The graphical user interface should be easy to understand, but let's go sure ;-)
 At the left side above the output field is an input field for the IP or the name
 of the target computer. Besides is a input field for the port, to which to connect, followed by
 the button "connect", which establishes a connection with the target, the button "disconnect"
 closes this connection and finally there's an empty input field for general inputs. If one
 writes something in this field, one only needs to press ENTER in order to send
 the input. Below these is a field for outputs and below that is the status bar.


 3. The settings
------------------------------------
 Settings can be set in two ways:
 1. Click on the input field and enter the option, which you want to change, and press ENTER.
    That's all : -)
    There are the following options (input in each case without the quotes, but with colon!):
         - ":tcp" to set TCP as current protocol
         - ":udp" to set UDP as current protocol
         - ":bin" or ":binary" to switch to binary mode
         - ":adv" or ":advanced" to switch to advanced mode
         - ":ascii" to switch to ASCII mode

         - ":scheme x" to change color scheme; x is the number of the scheme (1-9)
                        Table of color schemes:
                        Number        Textcolor           Background
                          1             White                Blue
                          2             Green                Black
                          3             White                Black
                          4             Yellow               Red
                          5             Black                Grey
                          6             Black                White
                          7             Yellow               Black
                          8             Black                Yellow
                          9             Yellow               Blue
         - ":winsock" to obtain winsock information
         - ":stats" to view connection statistics

 2. Settings may also be changed by clicking the status bar. The current protocol as well as
    the current mode used can be changed, through clicking the appropriate parts of the status
    bar, showing the responding information. Click the "Sent/Received Bytes"-area and a
    connection statistics will be displayed.

 Hit F1 or use command ":help" to dislpay (quick-)help within DevCont.
 IMPORTANT: Options may only be changed, when there's NO connection established!


 4. The different modes
-----------------------------
 4.1   ASCII mode
       This is the standard mode. It is perfectly suitable for protocols like SMTP or POP3.
       It transfers the input of the input field as completely normal ASCII text, however
       CR and LF characters are attached to each individual transfer. This corresponds to
       the format, as most Internet protocols expect it.

 4.2   Binary mode
       In binary mode the hexcode of the individual bytes is entered in the input field. It
       is only transmitted what is entered. Likewise only the hexcodes of the
       received bytes are displayed. This mode is meant for connections/protocols, which do
       not transmit plain and printable ASCII characters (e.g. SOCKS).

 4.3   Advanced mode
       This is actually the ASCII mode with items of the binary mode. Printable ASCII characters
       are transmitted but nothing is automatically attached. The special thing about this
       mode is the support of escape sequences known from the programming language C/C++. You
       can, with the aid of these escape sequences, mix the printable ASCII charactes with non
       printable ones. (Note: In order to make a backslash, you must use the \\ escape sequence)
       The advanced mode supports the following escape sequences:
           Sequence:            Decimal value:           Meaning:
              \a                    7                      BEL (bell)
              \b                    8                      BS (backspace)
              \t                    9                      HT (horizontal tabulator)
              \n                   10                      LF (line feed)
              \v                   11                      VT (vertical tabulator)
              \f                   12                      FF (form feed)
              \r                   13                      CR (carriage return)
              \\                   92                      Backslash
              \xzz                  -                      Character with hexcode zz



Have much fun with DevCont!
Stefan Partusch
http://www.partusch.de.vu.