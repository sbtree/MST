Um das Package TntUnicodeVcl_D70.dpk zu compilieren,
muss die Datei TntUnicodeVcl_R70.dcp vorhanden sein.
Diese wird beim Compilieren des Packages TntUnicodeVcl_R70.dpk erzeugt.
Es muss also zuerst das Package TntUnicodeVcl_R70.dpk und
anschlie�end das Package TntUnicodeVcl_D70.dpk compiliert werden.